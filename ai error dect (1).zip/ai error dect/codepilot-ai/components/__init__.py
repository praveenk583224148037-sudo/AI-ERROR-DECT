# CodePilot AI - UI Components
