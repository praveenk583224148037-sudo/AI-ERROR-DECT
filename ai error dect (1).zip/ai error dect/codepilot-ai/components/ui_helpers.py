"""
CodePilot AI - UI Helpers
Loading state, code editor area, error display.
"""
import streamlit as st


def loading_spinner(message: str = "Analyzing..."):
    """Context manager for analysis loading state."""
    return st.spinner(message)


def code_editor_placeholder(height: int = 400) -> str:
    """Default placeholder for code input."""
    return """def example():
    # Paste your code here
    x = 1
    return x + 1
"""


def show_error(message: str) -> None:
    """Display error in a clear way."""
    st.error(message)


def show_api_key_warning() -> None:
    """Notify user to set OPENAI_API_KEY."""
    st.warning(
        "**OpenAI API Key required.** Set `OPENAI_API_KEY` in a `.env` file in the project root, "
        "or in your environment, then restart the app."
    )
