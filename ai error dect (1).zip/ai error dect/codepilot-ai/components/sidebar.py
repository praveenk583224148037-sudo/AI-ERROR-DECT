"""
CodePilot AI - Sidebar Navigation
"""
import streamlit as st
from config import APP_NAME, APP_TAGLINE

# Page keys for session state
PAGES = {
    "Home": "home",
    "Code Analyzer": "code_analyzer",
    "Documentation Generator": "doc_generator",
    "Test Case Generator": "test_generator",
    "GitHub Analyzer": "github_analyzer",
    "Project Insights": "project_insights",
}


def render_sidebar() -> str:
    """
    Render sidebar and return selected page key.
    """
    with st.sidebar:
        st.markdown(f"# {APP_NAME}")
        st.caption(APP_TAGLINE)
        st.divider()
        selected = st.radio(
            "Navigate",
            options=list(PAGES.keys()),
            key="nav_radio",
            label_visibility="collapsed",
        )
        st.divider()
        st.caption("Store analyses in history for later review.")
    return PAGES.get(selected, "home")
