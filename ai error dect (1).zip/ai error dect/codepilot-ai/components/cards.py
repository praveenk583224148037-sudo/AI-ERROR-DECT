"""
CodePilot AI - Metric and Result Cards
"""
import streamlit as st


def metric_card(label: str, value: str | int | float, help_text: str = "") -> None:
    """Display a single metric in a styled container."""
    st.metric(label=label, value=value, help=help_text)


def quality_score_card(score: float) -> None:
    """Display code quality score 1-10 with color hint."""
    score = max(1, min(10, score))
    if score >= 8:
        color = "green"
    elif score >= 6:
        color = "orange"
    else:
        color = "red"
    st.markdown(
        f"""
        <div style="
            padding: 1rem 1.5rem;
            border-radius: 8px;
            background: rgba(30, 41, 59, 0.8);
            border-left: 4px solid var(--st-{color}-70, #22c55e);
            margin: 0.5rem 0;
        ">
            <span style="color: #94a3b8; font-size: 0.9rem;">Code Quality Score</span><br/>
            <span style="font-size: 2rem; font-weight: 700;">{score}/10</span>
        </div>
        """,
        unsafe_allow_html=True,
    )


def result_panel(title: str, content: str, expanded: bool = True) -> None:
    """Expandable panel for analysis result (Markdown)."""
    with st.expander(title, expanded=expanded):
        st.markdown(content or "_No output._")


def security_risk_badges(risks: list) -> None:
    """Show list of static security risks as badges."""
    if not risks:
        st.success("No static security risks detected.")
        return
    for r in risks[:15]:
        sev = r.get("severity", "medium")
        desc = r.get("description", "Risk")
        st.warning(f"**[{sev.upper()}]** {desc}")
