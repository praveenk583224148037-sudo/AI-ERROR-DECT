"""
CodePilot AI - FastAPI Backend
REST API for code analysis (optional; main UI is Streamlit).
Run: uvicorn api:app --reload
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional

from ai_engine import (
    explain_code,
    detect_bugs,
    generate_docs,
    generate_tests,
    compute_code_quality_score,
    detect_security_risks,
    full_analysis,
)
from github_analyzer import analyze_github_repo
from utils import get_code_stats
from database import init_db, save_analysis

init_db()

app = FastAPI(title="CodePilot AI", description="Your AI Senior Developer", version="1.0.0")


class CodeInput(BaseModel):
    code: str


class GitHubInput(BaseModel):
    url: str


@app.get("/")
def root():
    return {"app": "CodePilot AI", "tagline": "Your AI Senior Developer"}


@app.post("/analyze")
def analyze(code_input: CodeInput):
    """Full code analysis."""
    try:
        result = full_analysis(code_input.code)
        save_analysis(
            "full_analysis",
            f"Explanation:\n{result.get('explanation','')}\n\nBugs:\n{result.get('bugs','')}",
            input_code=code_input.code[:50000],
            metadata={"quality_score": result.get("quality_score"), "language": result.get("language")},
        )
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/explain")
def explain(code_input: CodeInput):
    stats = get_code_stats(code_input.code)
    return {"explanation": explain_code(code_input.code, stats.get("language", ""))}


@app.post("/bugs")
def bugs(code_input: CodeInput):
    stats = get_code_stats(code_input.code)
    return {"bugs": detect_bugs(code_input.code, stats.get("language", ""))}


@app.post("/docs")
def docs(code_input: CodeInput):
    stats = get_code_stats(code_input.code)
    return {"documentation": generate_docs(code_input.code, stats.get("language", ""))}


@app.post("/tests")
def tests(code_input: CodeInput):
    stats = get_code_stats(code_input.code)
    return {"tests": generate_tests(code_input.code, stats.get("language", ""))}


@app.post("/quality")
def quality(code_input: CodeInput):
    return compute_code_quality_score(code_input.code)


@app.post("/security")
def security(code_input: CodeInput):
    stats = get_code_stats(code_input.code)
    return {"security_analysis": detect_security_risks(code_input.code, stats.get("language", ""))}


@app.post("/github")
def github(github_input: GitHubInput):
    result = analyze_github_repo(github_input.url)
    if not result["success"]:
        raise HTTPException(status_code=400, detail=result.get("error", "Analysis failed"))
    return result
