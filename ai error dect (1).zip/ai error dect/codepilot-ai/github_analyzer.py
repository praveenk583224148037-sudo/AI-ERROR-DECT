"""
CodePilot AI - GitHub Repository Analyzer
Fetches repo structure and summarizes project; highlights potential issues.
"""
import logging
import re
from typing import Dict, Any, List, Optional
from urllib.parse import urlparse

import httpx
from openai import OpenAI

from config import OPENAI_API_KEY, OPENAI_MODEL

logger = logging.getLogger(__name__)

# Optional: PyGithub for deeper analysis; fallback to raw API
try:
    from github import Github
    HAS_GITHUB = True
except ImportError:
    HAS_GITHUB = False


def _get_openai_client() -> OpenAI:
    if not OPENAI_API_KEY:
        raise ValueError("OPENAI_API_KEY is not set.")
    return OpenAI(api_key=OPENAI_API_KEY)


def parse_github_url(url: str) -> Optional[tuple]:
    """
    Parse repo URL to (owner, repo). Supports:
    https://github.com/owner/repo
    https://github.com/owner/repo/
    github.com/owner/repo
    """
    url = url.strip()
    if "github.com" not in url:
        return None
    if not url.startswith("http"):
        url = "https://" + url
    parsed = urlparse(url)
    path = parsed.path.strip("/")
    parts = path.split("/")
    if len(parts) >= 2:
        return parts[0], parts[1].replace(".git", "")
    return None


def fetch_repo_structure(owner: str, repo: str) -> Dict[str, Any]:
    """
    Fetch repository tree (files and folders) using GitHub API.
    No auth required for public repos (rate limit applies).
    """
    api_base = f"https://api.github.com/repos/{owner}/{repo}"
    default_branch = "main"

    with httpx.Client(timeout=15.0) as client:
        # Get default branch
        r = client.get(api_base)
        if r.status_code != 200:
            raise ValueError(f"Repository not found or inaccessible: {r.status_code}")
        data = r.json()
        default_branch = data.get("default_branch", "main")

        # Get tree (recursive for file list)
        r = client.get(f"{api_base}/git/trees/{default_branch}?recursive=1")
        if r.status_code != 200:
            raise ValueError(f"Could not fetch tree: {r.status_code}")
        tree_data = r.json()
        tree = tree_data.get("tree", [])

    files = [t for t in tree if t.get("type") == "blob"]
    paths = [t.get("path", "") for t in files]
    return {
        "owner": owner,
        "repo": repo,
        "default_branch": default_branch,
        "files": paths,
        "file_count": len(paths),
    }


def fetch_file_content(owner: str, repo: str, path: str, branch: str = "main") -> str:
    """Fetch raw content of a single file from GitHub."""
    url = f"https://raw.githubusercontent.com/{owner}/{repo}/{branch}/{path}"
    with httpx.Client(timeout=10.0) as client:
        r = client.get(url)
        if r.status_code != 200:
            return ""
        return r.text


def summarize_project(structure: Dict[str, Any], sample_content: str = "") -> str:
    """
    Use LLM to summarize project from file list and optional file content.
    """
    client = _get_openai_client()
    file_list = "\n".join(structure.get("files", [])[:200])
    prompt = (
        "Based on the following repository file structure, provide a concise project summary.\n"
        "Include: likely purpose, tech stack (languages/frameworks), and main components.\n"
        "If code sample is provided, use it to refine the summary.\n\n"
        f"Repository: {structure.get('owner')}/{structure.get('repo')}\n\n"
        "Files:\n" + file_list
    )
    if sample_content:
        prompt += "\n\nSample code (first 3000 chars):\n```\n" + sample_content[:3000] + "\n```"

    resp = client.chat.completions.create(
        model=OPENAI_MODEL,
        messages=[{"role": "user", "content": prompt}],
        temperature=0.3,
    )
    return (resp.choices[0].message.content or "").strip()


def highlight_issues(structure: Dict[str, Any], summary: str) -> str:
    """
    Use LLM to highlight potential issues (structure, security, maintainability).
    """
    client = _get_openai_client()
    file_list = "\n".join(structure.get("files", [])[:150])
    prompt = (
        "You are a senior developer reviewing a project structure.\n\n"
        f"Project summary:\n{summary}\n\n"
        "File list:\n" + file_list + "\n\n"
        "List potential issues or improvements: security, structure, missing tests/docs, "
        "dependency risks, or best practices. Be concise; use bullet points."
    )
    resp = client.chat.completions.create(
        model=OPENAI_MODEL,
        messages=[{"role": "user", "content": prompt}],
        temperature=0.3,
    )
    return (resp.choices[0].message.content or "").strip()


def analyze_github_repo(url: str) -> Dict[str, Any]:
    """
    Full GitHub analysis: parse URL, fetch structure, summarize, highlight issues.
    """
    parsed = parse_github_url(url)
    if not parsed:
        return {
            "success": False,
            "error": "Invalid GitHub repository URL.",
            "structure": None,
            "summary": "",
            "issues": "",
        }
    owner, repo = parsed

    try:
        structure = fetch_repo_structure(owner, repo)
    except Exception as e:
        logger.exception("GitHub fetch failed")
        return {
            "success": False,
            "error": str(e),
            "structure": None,
            "summary": "",
            "issues": "",
        }

    # Optional: fetch a main file for better summary (e.g. main app, README)
    sample_content = ""
    for path in ["README.md", "main.py", "app.py", "src/main.py", "index.js"]:
        if path in structure.get("files", []):
            sample_content = fetch_file_content(
                owner, repo, path, structure.get("default_branch", "main")
            )
            if sample_content:
                break

    try:
        summary = summarize_project(structure, sample_content)
        issues = highlight_issues(structure, summary)
    except Exception as e:
        logger.exception("LLM analysis failed")
        summary = "Summary could not be generated."
        issues = f"Analysis error: {e}"

    return {
        "success": True,
        "error": None,
        "structure": structure,
        "summary": summary,
        "issues": issues,
        "url": url,
    }
