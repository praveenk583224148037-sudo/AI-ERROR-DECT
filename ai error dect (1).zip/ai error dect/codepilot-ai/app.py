"""
CodePilot AI - Main Application
Streamlit dashboard for AI-powered code analysis and productivity.
"""
import logging
import sys
from pathlib import Path

import streamlit as st

# Add project root to path
sys.path.insert(0, str(Path(__file__).resolve().parent))

from config import APP_NAME, APP_TAGLINE, OPENAI_API_KEY
from database import init_db, save_analysis, get_recent_analyses
from components.sidebar import render_sidebar
from components.cards import metric_card, quality_score_card, result_panel, security_risk_badges
from components.ui_helpers import loading_spinner, code_editor_placeholder, show_error, show_api_key_warning
from utils import get_code_stats, detect_security_risks_static
from ai_engine import (
    explain_code,
    detect_bugs,
    suggest_improvements,
    generate_docs,
    generate_tests,
    compute_code_quality_score,
    detect_security_risks,
    full_analysis,
)
from github_analyzer import analyze_github_repo

# Logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    stream=sys.stdout,
)
logger = logging.getLogger("codepilot")

# Page config - must be first Streamlit command
st.set_page_config(
    page_title=APP_NAME,
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Inject dark theme and custom styles
ASSETS_DIR = Path(__file__).resolve().parent / "assets"
CSS_FILE = ASSETS_DIR / "styles.css"
if CSS_FILE.exists():
    with open(CSS_FILE) as f:
        st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

# Initialize database
init_db()

# Sidebar navigation
page = render_sidebar()

# Helper to check API key for AI features
def has_api_key() -> bool:
    return bool(OPENAI_API_KEY and OPENAI_API_KEY.strip())


def page_home():
    """Landing / dashboard overview."""
    st.title(f"Welcome to {APP_NAME}")
    st.caption(APP_TAGLINE)
    st.markdown("---")
    col1, col2, col3 = st.columns(3)
    with col1:
        st.info("**Code Analyzer** – Paste code, get explanation, bugs, performance tips, and improvements.")
    with col2:
        st.info("**Docs & Tests** – Generate documentation and test cases from your code.")
    with col3:
        st.info("**GitHub Analyzer** – Enter a repo URL for structure and issue highlights.")
    st.markdown("---")
    st.subheader("Recent Analyses")
    recent = get_recent_analyses(limit=10)
    if not recent:
        st.caption("No analyses yet. Use the sidebar to run Code Analyzer or other tools.")
    else:
        for r in recent:
            with st.expander(f"{r['analysis_type']} – {r['timestamp'][:19]}", expanded=False):
                st.caption(f"ID: {r['id']}")
                if r.get("input_code"):
                    st.code(r["input_code"][:500] + ("..." if len(r["input_code"]) > 500 else ""), language="text")
                st.markdown(r["analysis_result"][:1500] + ("..." if len(r["analysis_result"]) > 1500 else ""))


def page_code_analyzer():
    """Full code analysis: explain, bugs, improvements, quality score, security."""
    st.title("Code Analyzer")
    st.caption("Paste your code for explanation, bug detection, improvements, quality score, and security review.")
    code = st.text_area(
        "Code",
        value=code_editor_placeholder(400),
        height=400,
        placeholder="Paste code here...",
        key="analyzer_code",
    )
    col1, col2 = st.columns([1, 4])
    with col1:
        analyze_btn = st.button("Analyze", type="primary", use_container_width=True)
    if not code or not code.strip():
        st.caption("Enter some code to analyze.")
        return
    stats = get_code_stats(code)
    st.markdown("**Quick stats**")
    c1, c2, c3, c4 = st.columns(4)
    with c1:
        metric_card("Lines", stats["line_count"], "Total lines")
    with c2:
        metric_card("Non-empty", stats["non_empty_lines"], "Lines with content")
    with c3:
        metric_card("Characters", stats["character_count"], "Total characters")
    with c4:
        metric_card("Language", stats["language"], "Detected language")
    if analyze_btn:
        if not has_api_key():
            show_api_key_warning()
            return
        with loading_spinner("Running full analysis..."):
            try:
                result = full_analysis(code)
                save_analysis(
                    "full_analysis",
                    f"Explanation:\n{result['explanation']}\n\nBugs:\n{result['bugs']}\n\nImprovements:\n{result['improvements']}\n\nSecurity:\n{result['security_analysis']}",
                    input_code=code[:50000],
                    metadata={"quality_score": result["quality_score"], "language": result["language"]},
                )
                quality_score_card(result["quality_score"])
                result_panel("Explanation", result["explanation"])
                result_panel("Potential bugs", result["bugs"])
                result_panel("Suggested improvements", result["improvements"])
                st.subheader("Security")
                security_risk_badges(result.get("security_risks_static", []))
                result_panel("Security analysis (AI)", result["security_analysis"], expanded=True)
            except Exception as e:
                logger.exception("Analysis failed")
                show_error(str(e))


def page_doc_generator():
    """Generate documentation from code."""
    st.title("Documentation Generator")
    st.caption("Generate developer docs: function descriptions, parameters, return values, usage examples.")
    code = st.text_area("Code", height=350, placeholder="Paste code here...", key="doc_code")
    if st.button("Generate documentation", type="primary", key="doc_btn"):
        if not code or not code.strip():
            st.warning("Paste some code first.")
            return
        if not has_api_key():
            show_api_key_warning()
            return
        with loading_spinner("Generating documentation..."):
            try:
                stats = get_code_stats(code)
                doc = generate_docs(code, stats.get("language", ""))
                save_analysis("documentation", doc, input_code=code[:50000])
                result_panel("Generated documentation", doc, expanded=True)
            except Exception as e:
                logger.exception("Doc generation failed")
                show_error(str(e))


def page_test_generator():
    """Generate test cases from code."""
    st.title("Test Case Generator")
    st.caption("Generate useful test cases for your code.")
    code = st.text_area("Code", height=350, placeholder="Paste code here...", key="test_code")
    if st.button("Generate tests", type="primary", key="test_btn"):
        if not code or not code.strip():
            st.warning("Paste some code first.")
            return
        if not has_api_key():
            show_api_key_warning()
            return
        with loading_spinner("Generating test cases..."):
            try:
                stats = get_code_stats(code)
                tests = generate_tests(code, stats.get("language", ""))
                save_analysis("test_cases", tests, input_code=code[:50000])
                result_panel("Generated test cases", tests, expanded=True)
            except Exception as e:
                logger.exception("Test generation failed")
                show_error(str(e))


def page_github_analyzer():
    """Analyze a GitHub repository."""
    st.title("GitHub Repository Analyzer")
    st.caption("Enter a GitHub repo URL to get structure, summary, and potential issues.")
    url = st.text_input("Repository URL", placeholder="https://github.com/owner/repo", key="github_url")
    if st.button("Analyze repository", type="primary", key="github_btn"):
        if not url or not url.strip():
            st.warning("Enter a GitHub repository URL.")
            return
        if not has_api_key():
            show_api_key_warning()
            return
        with loading_spinner("Fetching repo and analyzing..."):
            try:
                out = analyze_github_repo(url)
                if not out["success"]:
                    show_error(out.get("error", "Unknown error"))
                    return
                save_analysis(
                    "github_analysis",
                    f"Summary:\n{out['summary']}\n\nIssues:\n{out['issues']}",
                    input_url=url,
                    metadata={"repo": out.get("structure", {}).get("repo"), "owner": out.get("structure", {}).get("owner")},
                )
                st.success("Analysis complete.")
                result_panel("Project summary", out["summary"], expanded=True)
                result_panel("Potential issues", out["issues"], expanded=True)
                if out.get("structure"):
                    st.subheader("Repository structure")
                    files = out["structure"].get("files", [])
                    st.caption(f"Total files: {len(files)}")
                    st.code("\n".join(files[:100] + (["..."] if len(files) > 100 else [])), language="text")
            except Exception as e:
                logger.exception("GitHub analysis failed")
                show_error(str(e))


def page_project_insights():
    """Project insights: quality score and security only (no full AI)."""
    st.title("Project Insights")
    st.caption("Quick code quality score and security risk detection (no API key required for static checks).")
    code = st.text_area("Code", height=350, placeholder="Paste code here...", key="insights_code")
    if not code or not code.strip():
        st.caption("Paste code to see quality score and security risks.")
        return
    stats = get_code_stats(code)
    quality = compute_code_quality_score(code)
    quality_score_card(quality["score"])
    c1, c2, c3 = st.columns(3)
    with c1:
        metric_card("Lines", stats["line_count"])
    with c2:
        metric_card("Language", stats["language"])
    with c3:
        metric_card("Static security issues", quality.get("security_risk_count", 0))
    st.subheader("Quality factors")
    for factor, delta in quality.get("factors", []):
        st.caption(f"• {factor} ({delta})")
    st.subheader("Security risks (static)")
    security_risk_badges(detect_security_risks_static(code))
    if st.button("Run full security analysis (AI)", key="insights_ai_sec"):
        if not has_api_key():
            show_api_key_warning()
            return
        with loading_spinner("Running security analysis..."):
            try:
                sec = detect_security_risks(code, stats.get("language", ""))
                result_panel("Security analysis", sec, expanded=True)
            except Exception as e:
                show_error(str(e))


# Route to page
if page == "home":
    page_home()
elif page == "code_analyzer":
    page_code_analyzer()
elif page == "doc_generator":
    page_doc_generator()
elif page == "test_generator":
    page_test_generator()
elif page == "github_analyzer":
    page_github_analyzer()
elif page == "project_insights":
    page_project_insights()
else:
    page_home()
