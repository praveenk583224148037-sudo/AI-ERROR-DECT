"""
CodePilot AI - Utilities
Code statistics, language detection, and helpers.
"""
import re
import logging
from typing import Dict, Any, List, Tuple

logger = logging.getLogger(__name__)

# Simple language hints by extension and keywords
LANG_SIGNATURES = {
    "python": [r"def\s+\w+\s*\(", r"import\s+\w+", r"from\s+\w+\s+import", r"class\s+\w+", r"print\s*\("],
    "javascript": [r"function\s+\w+\s*\(", r"=>", r"const\s+\w+\s*=", r"let\s+\w+\s*=", r"require\s*\("],
    "typescript": [r"interface\s+\w+", r":\s*(string|number|boolean)", r"export\s+(const|function|class)"],
    "java": [r"public\s+(static\s+)?(void|class|\w+)\s+\w+", r"private\s+\w+", r"System\.out\.print"],
    "go": [r"func\s+\w+\s*\(", r"package\s+\w+", r":=\s*"],
    "rust": [r"fn\s+\w+\s*\(", r"let\s+(mut\s+)?\w+", r"impl\s+\w+"],
    "c": [r"#include\s*<", r"int\s+main\s*\(", r"printf\s*\("],
    "cpp": [r"#include\s*<", r"std::", r"namespace\s+\w+"],
}


def get_line_count(code: str) -> int:
    """Return number of lines (including empty)."""
    if not code or not code.strip():
        return 0
    return len(code.splitlines())


def get_non_empty_line_count(code: str) -> int:
    """Return count of non-empty lines."""
    if not code:
        return 0
    return sum(1 for line in code.splitlines() if line.strip())


def detect_language(code: str) -> str:
    """
    Heuristic language detection from code content.
    Returns language name or 'unknown'.
    """
    if not code or not code.strip():
        return "unknown"
    code_lower = code.strip()[:2000]
    scores: Dict[str, int] = {}
    for lang, patterns in LANG_SIGNATURES.items():
        scores[lang] = sum(1 for p in patterns if re.search(p, code_lower))
    if not scores:
        return "unknown"
    best = max(scores.items(), key=lambda x: x[1])
    return best[0] if best[1] > 0 else "unknown"


def get_code_stats(code: str) -> Dict[str, Any]:
    """Return basic code statistics for metrics cards."""
    return {
        "line_count": get_line_count(code),
        "non_empty_lines": get_non_empty_line_count(code),
        "character_count": len(code) if code else 0,
        "language": detect_language(code or ""),
    }


def detect_security_risks_static(code: str) -> List[Dict[str, Any]]:
    """
    Static scan for common security patterns.
    Returns list of { 'type': str, 'description': str, 'severity': str }.
    """
    risks: List[Dict[str, Any]] = []
    if not code:
        return risks

    patterns = [
        (r"\beval\s*\(", "eval() usage", "high"),
        (r"\bexec\s*\(", "exec() usage", "high"),
        (r"__import__\s*\(", "__import__() usage", "medium"),
        (r"password\s*=\s*['\"][^'\"]+['\"]", "Possible hardcoded password", "high"),
        (r"api_key\s*=\s*['\"][^'\"]+['\"]", "Possible hardcoded API key", "high"),
        (r"secret\s*=\s*['\"][^'\"]+['\"]", "Possible hardcoded secret", "high"),
        (r"pickle\.loads?\s*\(", "Unsafe pickle deserialization", "high"),
        (r"os\.system\s*\(", "os.system() - prefer subprocess", "medium"),
        (r"subprocess\.(call|run)\s*\([^)]*shell\s*=\s*True", "Shell=True in subprocess", "medium"),
        (r"sql\s*=\s*['\"].*%s", "Possible SQL string formatting (injection risk)", "high"),
        (r"\.format\s*\([^)]*\)\s*.*execute\s*\(", "String format in DB execute", "medium"),
    ]

    for pattern, desc, severity in patterns:
        for m in re.finditer(pattern, code, re.IGNORECASE):
            risks.append({
                "type": "static",
                "description": desc,
                "severity": severity,
                "snippet": code[max(0, m.start() - 20) : m.end() + 20].replace("\n", " "),
            })
    return risks
