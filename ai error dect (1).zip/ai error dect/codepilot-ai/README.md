# CodePilot AI

**Your AI Senior Developer**

A production-quality AI developer productivity platform that helps programmers analyze, understand, and improve code. Built for hackathon demos and daily use.

---

## Project Overview

CodePilot AI is a SaaS-style application that combines:

- **AI-powered code analysis** (explanation, bugs, performance, improvements)
- **Code quality scoring** (1–10 based on structure, complexity, security)
- **Security risk detection** (eval/exec, hardcoded secrets, unsafe patterns)
- **Documentation generation** (functions, parameters, return values, examples)
- **Test case generation** for your code
- **GitHub repository analysis** (structure, summary, potential issues)

All analyses are stored in a local SQLite database for history and insights.

---

## Features

| Feature | Description |
|--------|-------------|
| **Code Analyzer** | Paste code → get AI explanation, potential bugs, performance issues, suggested improvements |
| **Code Quality Score** | 1–10 score from code length, complexity, security patterns, structure |
| **Security Risk Detector** | Detects eval(), exec(), hardcoded passwords, unsafe imports, SQL risks |
| **Documentation Generator** | Auto-generate docs: function description, parameters, return values, usage examples |
| **Test Case Generator** | Generate useful test cases for the given code |
| **GitHub Repository Analyzer** | Enter repo URL → structure, project summary, highlighted issues |

---

## Tech Stack

| Layer | Technology |
|-------|------------|
| **Backend** | Python, FastAPI (optional API layer) |
| **Frontend** | Streamlit, modern dark UI |
| **AI** | OpenAI API (GPT-4o-mini default) |
| **Database** | SQLite (`data/codepilot.db`) |
| **GitHub** | GitHub REST API (httpx) |

---

## Installation Steps

1. **Clone or download** the project:

   ```bash
   cd codepilot-ai
   ```

2. **Create a virtual environment** (recommended):

   ```bash
   python -m venv venv
   # Windows
   venv\Scripts\activate
   # macOS/Linux
   source venv/bin/activate
   ```

3. **Install dependencies**:

   ```bash
   pip install -r requirements.txt
   ```

4. **Configure OpenAI API key** (required for AI features):

   - Create a `.env` file in the project root:

   ```env
   OPENAI_API_KEY=sk-your-openai-api-key
   OPENAI_MODEL=gpt-4o-mini
   ```

   - Or set the environment variable:

   ```bash
   set OPENAI_API_KEY=sk-your-key
   ```

---

## How to Run

Start the Streamlit app (main UI):

```bash
streamlit run app.py
```

Optional: run the FastAPI backend for REST API access:

```bash
uvicorn api:app --reload
```

Then use endpoints such as `POST /analyze`, `POST /explain`, `POST /github`, etc.

The app opens in your browser (default: http://localhost:8501).

- **Sidebar:** Home, Code Analyzer, Documentation Generator, Test Case Generator, GitHub Analyzer, Project Insights.
- **Code Analyzer:** Paste code → click **Analyze** → view explanation, bugs, improvements, quality score, security.
- **Documentation / Test Generator:** Paste code → generate docs or tests.
- **GitHub Analyzer:** Enter a GitHub repo URL → get summary and issues.
- **Project Insights:** Quick quality score and static security checks (no API key needed).

---

## Demo Instructions

1. **First run:** Open the app; go to **Code Analyzer**.
2. Paste a small Python or JavaScript snippet (e.g. a function with a potential bug).
3. Click **Analyze**. Wait for the loading spinner; then review:
   - Code quality score (1–10)
   - Explanation, bugs, improvements, security analysis
4. Try **Documentation Generator** and **Test Case Generator** with the same or different code.
5. In **GitHub Analyzer**, enter e.g. `https://github.com/owner/repo` and click **Analyze repository**.
6. Use **Project Insights** for instant quality + static security without using the API.

---

## Project Structure

```
codepilot-ai/
├── app.py                 # Main Streamlit application
├── ai_engine.py           # AI functions (explain, bugs, docs, tests, quality, security)
├── config.py              # Configuration and env vars
├── database.py            # SQLite and analysis_history
├── github_analyzer.py      # GitHub repo analysis
├── utils.py               # Code stats, language detection, static security
├── requirements.txt
├── README.md
├── .env                   # OPENAI_API_KEY (create locally)
├── components/
│   ├── sidebar.py         # Sidebar navigation
│   ├── cards.py           # Metric and result cards
│   └── ui_helpers.py      # Loading, code editor, errors
└── assets/
    └── styles.css         # Dark theme and dashboard styles
```

---

## Database

Table **analysis_history**:

| Column | Description |
|--------|-------------|
| id | Auto-increment primary key |
| timestamp | UTC ISO timestamp |
| analysis_type | full_analysis, documentation, test_cases, github_analysis |
| input_code | Code snippet (if applicable) |
| input_url | GitHub URL (if applicable) |
| analysis_result | Stored result text |
| metadata | JSON (e.g. quality_score, language) |

Data is stored under `data/codepilot.db`.

---

## Error Handling and Logs

- Missing **OPENAI_API_KEY**: The app shows a warning; AI features are disabled until the key is set.
- Failed analyses: Errors are caught and displayed in the UI; details are logged to the console.
- Logs: Use the default Python logging format (timestamp, level, message) for debugging.

---

## License

MIT. Use and extend for demos and production as needed.
