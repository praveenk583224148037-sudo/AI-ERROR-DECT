"""
CodePilot AI - AI Engine
Modular AI functions using OpenAI API for code analysis and generation.
"""
import json
import logging
from typing import Optional, Dict, Any, List

from openai import OpenAI
from config import OPENAI_API_KEY, OPENAI_MODEL
from utils import get_code_stats, detect_security_risks_static

logger = logging.getLogger(__name__)

# Lazy client
_client: Optional[OpenAI] = None


def _get_client() -> OpenAI:
    global _client
    if _client is None:
        if not OPENAI_API_KEY:
            raise ValueError(
                "OPENAI_API_KEY is not set. Add it to .env or environment."
            )
        _client = OpenAI(api_key=OPENAI_API_KEY)
    return _client


def _chat(system: str, user: str, temperature: float = 0.3) -> str:
    """Single completion call. Returns content or raises."""
    client = _get_client()
    resp = client.chat.completions.create(
        model=OPENAI_MODEL,
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
        temperature=temperature,
    )
    return (resp.choices[0].message.content or "").strip()


def explain_code(code: str, language: str = "") -> str:
    """
    Generate a clear explanation of what the code does.
    """
    lang_note = f" (language: {language})" if language else ""
    system = (
        "You are an expert software engineer. Explain code clearly and concisely. "
        "Cover: purpose, main logic, and important data flow. Use bullet points when helpful."
    )
    user = f"Explain this code{lang_note}:\n\n```\n{code[:8000]}\n```"
    return _chat(system, user)


def detect_bugs(code: str, language: str = "") -> str:
    """
    Analyze code for potential bugs and edge cases.
    """
    lang_note = f" (language: {language})" if language else ""
    system = (
        "You are a senior developer doing a code review. List potential bugs, "
        "edge cases, and logical errors. For each: brief title, short explanation, "
        "and severity (high/medium/low). Be concise."
    )
    user = f"Find potential bugs in this code{lang_note}:\n\n```\n{code[:8000]}\n```"
    return _chat(system, user)


def suggest_improvements(code: str, language: str = "") -> str:
    """
    Suggest performance and quality improvements.
    """
    lang_note = f" (language: {language})" if language else ""
    system = (
        "You are a senior engineer. Suggest specific improvements for: "
        "performance, readability, maintainability, and best practices. "
        "Keep each suggestion short with a clear reason."
    )
    user = f"Suggest improvements for this code{lang_note}:\n\n```\n{code[:8000]}\n```"
    return _chat(system, user)


def generate_docs(code: str, language: str = "") -> str:
    """
    Generate developer documentation: functions, parameters, returns, examples.
    """
    lang_note = f" (language: {language})" if language else ""
    system = (
        "You are a technical writer. Generate developer documentation for the given code. "
        "Include: function/class names, descriptions, parameters, return values, "
        "and short usage examples. Use clear headings and bullet points. Output in Markdown."
    )
    user = f"Generate documentation for this code{lang_note}:\n\n```\n{code[:8000]}\n```"
    return _chat(system, user)


def generate_tests(code: str, language: str = "") -> str:
    """
    Generate useful test cases for the given code.
    """
    lang_note = f" (language: {language})" if language else ""
    system = (
        "You are a test engineer. Generate practical test cases for the given code. "
        "Include: unit tests for main functions, edge cases, and a few integration-style cases. "
        "Output executable test code in the same language as the snippet, plus a short list of what each test checks. Use Markdown for the list and code blocks for the tests."
    )
    user = f"Generate test cases for this code{lang_note}:\n\n```\n{code[:8000]}\n```"
    return _chat(system, user)


def compute_code_quality_score(code: str) -> Dict[str, Any]:
    """
    Compute a 1-10 quality score based on length, complexity, security, structure.
    Uses heuristics + static security scan; optional LLM for structure feedback.
    """
    stats = get_code_stats(code)
    security_risks = detect_security_risks_static(code)

    # Base score 10, deduct for issues
    score = 10.0
    factors = []

    # Length: very short or very long penalized
    lines = stats["line_count"]
    if lines == 0:
        score -= 3
        factors.append(("Empty or no code", -3))
    elif lines < 5:
        score -= 1
        factors.append(("Very short snippet", -1))
    elif lines > 500:
        score -= 1.5
        factors.append(("Very long file (consider splitting)", -1.5))

    # Security
    high_sec = sum(1 for r in security_risks if r.get("severity") == "high")
    med_sec = sum(1 for r in security_risks if r.get("severity") == "medium")
    if high_sec:
        score -= min(3, high_sec * 1.5)
        factors.append((f"High security risks ({high_sec})", -min(3, high_sec * 1.5)))
    if med_sec:
        score -= min(1.5, med_sec * 0.5)
        factors.append((f"Medium security risks ({med_sec})", -min(1.5, med_sec * 0.5)))

    # Simple complexity proxy: long lines, deep nesting
    for line in (code or "").splitlines():
        if len(line) > 120:
            score -= 0.2
            factors.append(("Very long lines (readability)", -0.2))
            break
    if code and code.count("    ") > 50:
        score -= 0.5
        factors.append(("Deep nesting / complexity", -0.5))

    score = max(1.0, min(10.0, round(score, 1)))
    return {
        "score": score,
        "factors": factors[:8],
        "stats": stats,
        "security_risk_count": len(security_risks),
    }


def detect_security_risks(code: str, language: str = "") -> str:
    """
    AI-assisted security analysis; combines static scan summary with LLM insights.
    """
    static_risks = detect_security_risks_static(code)
    static_summary = ""
    if static_risks:
        static_summary = "Static scan found:\n" + "\n".join(
            f"- [{r.get('severity', '?')}] {r.get('description', '')}" for r in static_risks[:15]
        )
    else:
        static_summary = "Static scan found no common issues."

    lang_note = f" (language: {language})" if language else ""
    system = (
        "You are a security-focused code reviewer. Analyze the code for security risks: "
        "injection, hardcoded secrets, unsafe deserialization, dangerous functions, etc. "
        "List each finding with severity and a short mitigation. Output in Markdown."
    )
    user = (
        f"{static_summary}\n\n"
        f"Also review this code for any other security issues{lang_note}:\n\n```\n{code[:8000]}\n```"
    )
    return _chat(system, user)


def full_analysis(code: str) -> Dict[str, Any]:
    """
    Run full analysis: explanation, bugs, improvements, quality score, security.
    Returns a dict with all results for the dashboard.
    """
    stats = get_code_stats(code)
    language = stats.get("language", "unknown")

    explanation = explain_code(code, language)
    bugs = detect_bugs(code, language)
    improvements = suggest_improvements(code, language)
    quality = compute_code_quality_score(code)
    security_text = detect_security_risks(code, language)

    return {
        "explanation": explanation,
        "bugs": bugs,
        "improvements": improvements,
        "quality_score": quality["score"],
        "quality_factors": quality.get("factors", []),
        "quality_stats": quality.get("stats", {}),
        "security_analysis": security_text,
        "security_risks_static": detect_security_risks_static(code),
        "language": language,
    }
