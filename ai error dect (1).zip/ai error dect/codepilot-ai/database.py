"""
CodePilot AI - Database Layer
SQLite storage for analysis history.
"""
import sqlite3
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Optional, List, Dict, Any

from config import DB_PATH

logger = logging.getLogger(__name__)


def get_connection() -> sqlite3.Connection:
    """Return a connection to the SQLite database."""
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    """Create analysis_history table if it does not exist."""
    conn = get_connection()
    try:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS analysis_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                analysis_type TEXT NOT NULL,
                input_code TEXT,
                input_url TEXT,
                analysis_result TEXT NOT NULL,
                metadata TEXT
            )
        """)
        conn.commit()
        logger.info("Database initialized: analysis_history table ready.")
    finally:
        conn.close()


def save_analysis(
    analysis_type: str,
    analysis_result: str,
    input_code: Optional[str] = None,
    input_url: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> int:
    """
    Save one analysis record. Returns the new row id.
    """
    conn = get_connection()
    try:
        cursor = conn.execute(
            """
            INSERT INTO analysis_history
            (timestamp, analysis_type, input_code, input_url, analysis_result, metadata)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                datetime.utcnow().isoformat(),
                analysis_type,
                input_code or "",
                input_url or "",
                analysis_result,
                json.dumps(metadata or {}),
            ),
        )
        conn.commit()
        return cursor.lastrowid
    finally:
        conn.close()


def get_recent_analyses(limit: int = 20) -> List[Dict[str, Any]]:
    """Fetch recent analyses for display in UI."""
    conn = get_connection()
    try:
        rows = conn.execute(
            """
            SELECT id, timestamp, analysis_type, input_code, input_url, analysis_result, metadata
            FROM analysis_history
            ORDER BY id DESC
            LIMIT ?
            """,
            (limit,),
        ).fetchall()
        return [
            {
                "id": r["id"],
                "timestamp": r["timestamp"],
                "analysis_type": r["analysis_type"],
                "input_code": r["input_code"],
                "input_url": r["input_url"],
                "analysis_result": r["analysis_result"],
                "metadata": json.loads(r["metadata"] or "{}"),
            }
            for r in rows
        ]
    finally:
        conn.close()
